GITOSIS = YAML.load_file("#{Rails.root}/config/gitosis.yml")
